<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentRecord extends Model {
    use HasFactory;

    protected $connection = 'mysql2';

    protected $guarded = [
        'id'
    ];

    public function student() {
        return $this->hasOne(SmStudent::class, 'student_id');
    }

    public function class() {
        return $this->belongsTo(SmClass::class, 'class_id');
    }

    public function section() {
        return $this->belongsTo(SmSection::class, 'section_id');
    }
}