<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmStudent extends Model {
    use HasFactory;

    protected $connection = 'mysql2';

    protected $guarded = [
        'id'
    ];

    public function gender() {
        return $this->belongsTo(SmBaseSetup::class, 'gender_id');
    }

    public function category() {
        return $this->belongsTo(SmStudentCategory::class, 'student_category_id');
    }

    public function group() {
        return $this->belongsTo(SmStudentGroup::class, 'student_group_id');
    }

    public function class() {
        return $this->belongsTo(SmClass::class, 'class_id');
    }

    public function section() {
        return $this->belongsTo(SmSection::class, 'section_id');
    }

    public function studentRecords() {
        return $this->hasMany(StudentRecord::class, 'student_id', 'id')->where('is_promote', 0)->where('active_status', 1);
    }
}